package io.iscsc.todoapp1;

import static java.lang.Thread.sleep;

import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 */
public class SETDate extends AppCompatActivity {

    Button button;
    CalendarView calendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_view);

        button = findViewById(R.id.date_pick);
        calendarView = findViewById(R.id.calendarView);

        Date date = new Date();
        date.getTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日:HH:mm:ss");
        String dateString = format.format(date);
        System.out.println(dateString);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendarView.getDate();
            }
        });







    }
}
